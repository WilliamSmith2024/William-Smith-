# Install packages and load libraries
install.packages("ez")
install.packages("tidyverse")
install.packages("psyntur")
install.packages("lme4")
install.packages("effects")
install.packages("emmeans")
library(effects)
library(ez)
library(tidyverse)
library(psyntur)
library(lme4)
library(emmeans)

update.packages(ask = FALSE)

#demographic 

# Let's have a look at the descriptive statistics using the EZ package
ezStats(
  data = Data_Project,
  dv = Correct,
  wid = ParticipantID,
  within = Condition,
  between = Group
)

#model summary 

# Let's have a look at the ANOVA using the EZ package
ezANOVA(
  data = Data_Project,
  dv = Correct,
  wid = ParticipantID,
  within = Condition,
  between = Group
)


# Let's make a plot
ezPlot(
  data = Data_Project,
  dv = Correct,
  wid = ParticipantID,
  within = Condition,
  between = Group,
  x = Condition,
  split = Group
) + theme_bw()



# Let's try a Generalised Linear Mixed Effects Model 
DataMixed <- glmer(Correct ~ (1 | ParticipantID) + Condition*Group,
                   family = "binomial",
                   data = Data_Project)
summary(DataMixed)

# Extract Coefficients
coefficients <- coef(DataMixed)

# Compare Results
print(coefficients)

# Let's make a plot, then:
DataMixedEffects <- predictorEffect("Condition", DataMixed)
DataMixedEffects

#summary of the model 
summary(DataMixedEffects)

#plotting data 

#plotting the model 
plot(DataMixedEffects, main = "")


#post hoc testing / emmeans 

# Compute EMMs for each level of Condition and Group
emm <- emmeans(DataMixed, ~ Condition * Group)

# Conduct pairwise comparisons for Condition within each level of Group
pairs(emm, by = "Group")

# Adjust for multiple comparisons using Tukey's method: groups
pairs(emm, by = "Group", adjust = "tukey")

# Adjust for multiple comparisons using Tukey's method:conditions 
pairs(emm, by = "Condition", adjust = "tukey")




